import random
user_choice = ["R", "P", "S"]
com_choice = random.choice(user_choice)
command = ""
while True:
    print("Welcome to Rock Paper Scissors Game by Bern2017")
    print("Press 1 to start game")
    print("Press 2 help for instuctions to play ")
    print("Press 3 to quit")
    print('..................................................')

    command = int(input(">  "))
    while command == 1:
        print("Game intialized")
        player = input('Make your choice; R or P or S ').upper()
        if player == com_choice:
            print(f"Computer choose: {com_choice}")
            print(f" It's a tie")
        elif player == 'R' and com_choice == "P":
            print(f"Computer choose: {com_choice}")
            print(" Computer wins")
        elif player == 'R' and com_choice == "S":
            print(f"Computer choose: {com_choice}")
            print("Player wins")
        elif player == "P" and com_choice == "R":
            print(f"Computer choose: {com_choice}")
            print("Player wins")
        elif player == "P" and com_choice == "S":
            print(f"Computer choose: {com_choice}")
            print("Computer wins")
        elif player == "S" and com_choice == "R":
            print(f"Computer choose: {com_choice}")
            print("Computer wins")
        elif player == "S" and com_choice == "P":
            print(f"Computer choose: {com_choice}")
            print("Player wins")
        elif player == "3":
            command = 3
            print("Game ended")
            print("Thanks for playing")
            print("Goodbye!")
        else:
            print("wrong input")
    if command == 2:
        print("""Press 1 to start game
        Then make a choice between Rock, Paper, and Scisors""")
    if command == 3:
        print("Game ended")
        print("Good bye")
        break
    else:
        print("wrong input")